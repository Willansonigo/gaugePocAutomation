package automation;

import automation.utils.DriverUtils;
import automation.web.faturamento.Parametro;
import com.thoughtworks.gauge.BeforeClassSteps;
import com.thoughtworks.gauge.Step;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Classe ParametroStepImplementation
 *
 * Essa classe é responsável por implementar os Steps específicos para a funcionalidade dos parâmetros.
 *
 * @author Felipe Di Bernardi S Thiago
 */
public class ParametroStepImplementation {

    private Parametro parametro;

    private DriverUtils utils;

    @BeforeClassSteps
    public void init() {
        parametro = new Parametro();
        utils = DriverUtils.getInstance();
    }

    @Step("Popular os campos Chave, Valor, Descricao e Categoria com os respectivos valores: " +
            "<chave>, <valor>, <descricao> e <categoria>")
    public void criarParametroCampoAberto(String chave, String valor, String descricao, String categoria) {
        parametro.createStringParameter(chave, valor, descricao, categoria);
        parametro.findParameterByKey(chave);
        String chaveCriada = utils
                .findElementByCssSelector("#formDataTable\\:parametroDT_data > tr:nth-of-type(1) > td:nth-of-type(2)")
                .getText();
        assertThat(chaveCriada).isEqualTo(chave);
    }

    @Step("Buscar e remover o parametro com a chave <chave>")
    public void removerParametroPelaChave(String chave) {
        parametro.findParameterByKey(chave);
        parametro.removeParameter();
        utils.waitUntilElementInvisibleByCssSelector(10, ".ui-widget-overlay.ui-dialog-mask");
        parametro.findParameterByKey(chave);
        String tabelaVaziaMensagem = utils.findElementByCssSelector(".ui-datatable-empty-message > td").getText();
        assertThat(tabelaVaziaMensagem).isEqualTo("Sem dados para exibir");
    }

}
