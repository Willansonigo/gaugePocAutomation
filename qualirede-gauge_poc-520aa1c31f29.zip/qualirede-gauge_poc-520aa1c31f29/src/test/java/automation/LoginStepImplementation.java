package automation;

import static org.assertj.core.api.Assertions.assertThat;

import automation.utils.DriverUtils;
import automation.web.login.Login;
import com.thoughtworks.gauge.BeforeClassSteps;
import com.thoughtworks.gauge.Step;

public class LoginStepImplementation {

    private Login login;
    private DriverUtils utils;

    @BeforeClassSteps
    public void init() {
        login = new Login();
        utils = DriverUtils.getInstance();
    }
    
    @Step("Abra o <site> e verifique se o titulo eh igual a <titulo>")
    public void verificarNomeSite(String site, String titulo) {
        login.openWebsite(site);
    	assertThat(utils.getSiteTitle()).isEqualTo(titulo);
    }
    
    @Step("Faca login no <site> com as credenciais: <usuario>, <senha>")
    public void logar(String website, String username, String password) {
    	login.executeLogin(website, username, password);
        assertThat(utils.findElementByTag("h1").getText()).isEqualTo("Bem-vindo!");
    }



}
