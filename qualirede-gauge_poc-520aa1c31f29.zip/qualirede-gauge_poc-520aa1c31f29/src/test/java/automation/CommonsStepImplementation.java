package automation;

import automation.utils.DriverUtils;
import automation.web.Commons;
import com.thoughtworks.gauge.Step;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Classe CommonsStepImplementation
 * <p>
 * Essa classe é responsável por...
 *
 * @author Felipe Di Bernardi S Thiago
 */
public class CommonsStepImplementation {

    private Commons commons;
    private DriverUtils utils;

    {
        commons = new Commons();
        utils = DriverUtils.getInstance();
    }

    @Step("Entre na aplicacao <appName>")
    public void acessarAplicacao(String appName) {
        commons.accessApplication(appName);
        assertThat(utils.waitUntilPresenceOfElementByCssSelector(10,".panel-body > h3").getText())
                .isEqualTo("Bem vindo");
    }

    @Step("Acesse o menu <menu>")
    public void acessarMenu(String menu) {
        commons.accessMenu(menu);
//        utils.closeWebsite();
    }

    @Step("Acesse o submenu <submenu>")
    public void acessarSubmenu(String submenu) {
        commons.accessSubmenu(submenu);
    }

    @Step("Acesse o botao para cadastrar novo")
    public void acessarCriacaoNovoItem() {
        commons.accessNewButton();
    }

}
