package automation;

import automation.utils.DriverUtils;
import automation.web.faturamento.CodigoCobranca;
import automation.web.faturamento.Parametro;
import com.thoughtworks.gauge.BeforeClassSteps;
import com.thoughtworks.gauge.Step;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Classe CodigoCobrancaStepImplementation
 *
 * Essa classe é responsável por implementar os Steps específicos para a funcionalidade do código de cobrança.
 *
 * @author Sandro Ireno Martins Junior
 */

public class CodigoCobrancaStepImplementation {

    private CodigoCobranca codigoCobranca;
    private DriverUtils utils;

    @BeforeClassSteps
    public void init() {
        codigoCobranca = new CodigoCobranca();
        utils = DriverUtils.getInstance();
    }

    @Step("Popular os campos Codigo, Descricao, Tipo, Cobrar Juros, Juros, Multa, Gerar Estorno, Numero Consignataria, Cod. VD, Grau de Parentesco, Codigo Atrasado" +
            " com os respectivos valores: <codigo>, <descricao>, <tipo>, <cobrarJuros>, <juros>, <multa>, <gerarEstorno>, <nrConsignataria>, <codVd>, <grauParentesco>, " +
            "<codigoAtrasado>")
    public void criarCodigoCobranca(String codigo, String descricao, String tipo, String cobrarJuros, String juros, String multa, String gerarEstorno,
                                    String nrConsignataria, String codVd, String grauParentesco, String codigoAtrasado) {
        codigoCobranca.createCodigoCobranca(codigo, descricao, tipo, cobrarJuros, juros, multa, gerarEstorno, nrConsignataria, codVd, grauParentesco, codigoAtrasado);

        String chaveCriada = utils
                .findElementById("form-cadastro-codigos-cobranca:codigo_input")
                .getAttribute("value");
        assertThat(chaveCriada).isEqualTo(codigo);
    }

}
