package automation.data;

public enum Sistema {
	

	
}
