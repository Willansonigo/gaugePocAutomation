package automation.web;

import automation.utils.DriverUtils;

/**
 * Classe Commons
 * <p>
 * Essa classe é responsável por...
 *
 * @author Felipe Di Bernardi S Thiago
 */
public class Commons {

    private DriverUtils utils = DriverUtils.getInstance();

    /**
     * Acessa a aplicação de acordo com o nome informado.
     * @param appName Nome da aplicação que se deseja acessar.
     */
    public void accessApplication(String appName) {
        utils.waitUntilPresenceOfElementByText(5, appName).click();
    }

    /**
     * Acessa um menu do sistema através do nome informado.
     * @param menuText Nome do menu que se deseja acessar.
     */
    public void accessMenu(String menuText) {
        utils.waitUntilPresenceOfElementByText(10, menuText).click();
    }

    /**
     * Acessa um submenu do sistema através do nome informado.
     * @param submenuText Nome do submenu que se deseja acessar.
     */
    public void accessSubmenu(String submenuText) {
        utils.waitUntilPresenceOfElementByText(10, submenuText).click();
    }

    public void accessNewButton() {
        utils.waitUntilPresenceOfElementByCssSelector(10, "i.fa.fa-plus.fa-2x").click();
    }
}
