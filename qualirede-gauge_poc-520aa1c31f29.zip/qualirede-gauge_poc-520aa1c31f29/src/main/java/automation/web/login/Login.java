package automation.web.login;

import automation.utils.DriverUtils;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Classe Login
 *
 * Essa classe é responsável por implementar as funcionalidades para interagir com a tela de login.
 *
 * @author Felipe Di Bernardi S Thiago
 */
public class Login {

    private DriverUtils utils;

    public Login() {
        this.utils = DriverUtils.getInstance();
    }

    public void openWebsite(String website) {
        utils.openWebsite(website);
    }

    public void executeLogin(String website, String username, String password) {
        openWebsite(website);
        utils.findElementById("username").sendKeys(username);
        utils.findElementById("senha").sendKeys(password);
        utils.findElementById("submit").click();

    }

    public void accessApplication(String appName) {
        utils.waitUntilPresenceOfElementByText(5, appName).click();
    }

    public void accessMenu(String menuText) {
        utils.waitUntilPresenceOfElementByText(10, menuText).click();
    }
}
