package automation.web.faturamento;

import automation.utils.DriverUtils;

/**
 * Classe CodigoCobranca
 *
 * Essa classe é responsável por implementar as funções específicas a serem executadas dentro da funcionalidade de
 * código de cobrança do Faturamento.
 *
 * @author Sandro Ireno Martins Junior
 */

public class CodigoCobranca {

    private DriverUtils utils = DriverUtils.getInstance();

    public void createCodigoCobranca(String codigo, String descricao, String tipo, String cobrarJuros, String juros, String multa, String gerarEstorno,
                                     String nrConsignataria, String codVd, String grauParentesco, String codigoAtrasado) {

        utils.findElementById("form-cadastro-codigos-cobranca:codigo_input").sendKeys(codigo);
        utils.findElementById("form-cadastro-codigos-cobranca:descricao").sendKeys(descricao);
        //Combo box campo: Tipo
        utils.findElementByCssSelector(".ui-selectonemenu-label:first-of-type").click();
        utils.waitUntilPresenceOfElementByCssSelector(10, "li[data-label="+tipo+"]").click();
        utils.findElementById("form-cadastro-codigos-cobranca:juros_input").sendKeys(juros);
        utils.findElementById("form-cadastro-codigos-cobranca:multa_input").sendKeys(multa);
        if(cobrarJuros.equals("Verdadeiro")){
            utils.findElementById("form-cadastro-codigos-cobranca:cobrarJuros").click();
        }
        if(gerarEstorno.equals("Verdadeiro")){
            utils.findElementById("form-cadastro-codigos-cobranca:gerarEstorno").click();
        }
        utils.findElementByCssSelector("div.col-md-3 > span.ui-inputnumber.ui-widget > input.ui-inputfield").sendKeys(nrConsignataria);
        utils.findElementByCssSelector("div.col-md-3 > input.ui-inputfield.ui-inputtext").sendKeys(codVd);
        //Combo box campo: Grau de parentesco
        utils.findElementByCssSelector("div.col-md-4 > div.ui-selectonemenu").click();
        utils.waitUntilPresenceOfElementByCssSelector(10, "li[data-label="+grauParentesco+"]").click();
        //Combo box campo: Código Atrasado
        utils.findElementByCssSelector("div.col-md-4 > div.controls > div.ui-selectonemenu > label.ui-selectonemenu-label").click();
        utils.waitUntilPresenceOfElementByCssSelector(10, "li[data-label="+codigoAtrasado+"]").click();

        utils.findElementByCssSelector("i.fa.fa-floppy-o.fa-2x").click();
    }
}
