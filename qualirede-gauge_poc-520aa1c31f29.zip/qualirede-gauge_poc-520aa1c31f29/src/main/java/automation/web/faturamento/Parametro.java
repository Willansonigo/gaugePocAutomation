package automation.web.faturamento;

import automation.utils.DriverUtils;
import org.openqa.selenium.WebElement;

import java.util.concurrent.TimeUnit;

/**
 * Classe Parametro
 *
 * Essa classe é responsável por implementar as funções específicas a serem executadas dentro da funcionalidade de
 * parâmetro do Faturamento.
 *
 * @author Felipe Di Bernardi S Thiago
 */
public class Parametro {

    private DriverUtils utils = DriverUtils.getInstance();

    public void createStringParameter(String key, String value, String description, String category) {
        utils.findElementById("form:chave").sendKeys(key);
        utils.findElementByCssSelector("label[for=form\\:radioTipo\\:1]").click();
        utils.waitUntilPresenceOfElementById(10, "form:valorCampoAberto").sendKeys(value);
        utils.findElementById("form:descricao").sendKeys(description);
        utils.findElementById("form:selCategoria_label").click();
        utils.waitUntilPresenceOfElementById(10, "form:selCategoria_1").click();
        utils.findElementByCssSelector("i.fa.fa-floppy-o.fa-2x").click();
    }

    public void findParameterByKey(String key) {
        WebElement input = utils.waitUntilPresenceOfElementByCssSelector(10,
                ".ui-inputfield:nth-of-type(1)");
        input.clear();
        input.sendKeys(key);
        utils.findElementByCssSelector("i.fa.fa-search.fa-2x").click();
    }

    public void removeParameter() {
        utils.waitUntilPresenceOfElementByCssSelector(10,
                "i.fa.fa-trash.fa-lg:first-of-type").click();
        utils.wait(2, TimeUnit.SECONDS);
        utils.waitUntilPresenceOfElementByCssSelector(10,".ui-confirmdialog-yes").click();
    }


}
