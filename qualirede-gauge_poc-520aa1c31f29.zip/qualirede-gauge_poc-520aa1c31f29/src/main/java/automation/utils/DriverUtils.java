package automation.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Classe DriverUtils
 *
 * Essa classe é responsável por...
 *
 * @author Felipe Di Bernardi S Thiago
 */
public class DriverUtils {

    private static DriverUtils utils;

    private static WebDriver driver;

    public DriverUtils() {
        System.setProperty("webdriver.gecko.driver", "C:/geckodriver/geckodriver.exe");
        driver = new FirefoxDriver();
    }

    public static DriverUtils getInstance() {
        if (utils == null) {
            utils = new DriverUtils();
        }
        return utils;
    }

    /**
     * Abre o site passado no parâmetro.
     * @param website Site que se deseja abrir.
     */
    public void openWebsite(String website) {
        driver.get(website);
    }

    public void closeWebsite() {
        driver.quit();
    }

    /**
     * Busca o título do site.
     * @return Título do site.
     */
    public String getSiteTitle() {
        return driver.getTitle();
    }

    /**
     * Chama o navegador
     */
    public void invokeBrowser(boolean deleteCookies) {
        try {
            driver.manage().window().maximize();
            if (deleteCookies) {
                driver.manage().deleteAllCookies();
            }
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    /**
     * Busca um elemento na DOM por seu texto.
     * OBS.: Se houver mais de um elemento com o mesmo texto, retorna o primeiro.
     * @param text Texto do elemento que se deseja encontrar.
     * @return Elemento na DOM.
     */
    public WebElement findElementByText(String text) {
        return driver.findElement(By.linkText(text));
    }

    /**
     * Busca um elemento na DOM por seu texto parcial.
     * OBS.: Se houver mais de um elemento com o mesmo texto, retorna o primeiro.
     * @param text Texto do elemento que se deseja encontrar.
     * @return Elemento na DOM.
     */
    public WebElement findElementByPartialText(String text) {
        return driver.findElement(By.partialLinkText(text));
    }

    /**
     * Busca um elemento na DOM por seu id.
     * @param id Id do elemento na DOM.
     * @return Elemento na DOM.
     */
    public WebElement findElementById(String id) {
        return driver.findElement(By.id(id));
    }

    /**
     * Busca um elemento na DOM por seu name.
     * @param name Name do elemento na DOM.
     * @return Elemento na DOM.
     */
    public WebElement findElementByName(String name) {
        return driver.findElement(By.name(name));
    }
    
    /**
     * Busca um elemento na DOM por seu seletor CSS.
     * OBS.: Se houver mais de um elemento com o mesmo seletor, retorna o primeiro.
     * @param cssSelector Seletor css do elemento na DOM.
     * @return Elemento na DOM.
     */
    public WebElement findElementByCssSelector(String cssSelector) {
        return driver.findElement(By.cssSelector(cssSelector));
    }

    /**
     * Busca um elemento na DOM por sua tag.
     * OBS.: Se houver mais de um elemento com a mesma tag, retorna o primeiro.
     * @param tag Nome da tag do elemento.
     * @return Elemento na DOM.
     */
    public WebElement findElementByTag(String tag) {
        return driver.findElement(By.tagName(tag));
    }

    /**
     * Busca um elemento na DOM por sua tag.
     * OBS.: Se houver mais de um elemento com a mesma classe, retorna o primeiro.
     * @param className Classe do elemento.
     * @return Elemento na DOM.
     */
    public WebElement findElementByClassName(String className) {
        return driver.findElement(By.className(className));
    }

    /**
     * Busca um elemento na DOM por seu XPath.
     * @param xpath Texto do elemento que se deseja encontrar.
     * @return Elemento na DOM.
     */
    public WebElement findElementByXPath(String xpath) {
        return driver.findElement(By.xpath(xpath));
    }

    /**
     * Busca os elementos na DOM por seu texto.
     * OBS.: Se houver mais de um elemento com o mesmo texto, retorna o primeiro.
     * @param text Texto do elemento que se deseja encontrar.
     * @return Elemento na DOM.
     */
    public List<WebElement> findElementsByText(String text) {
        return driver.findElements(By.linkText(text));
    }

    /**
     * Busca os elementos na DOM por seu texto parcial.
     * OBS.: Se houver mais de um elemento com o mesmo texto, retorna o primeiro.
     * @param text Texto do elemento que se deseja encontrar.
     * @return Elemento na DOM.
     */
    public List<WebElement> findElementsByPartialText(String text) {
        return driver.findElements(By.partialLinkText(text));
    }

    /**
     * Busca os elementos na DOM por seu id.
     * @param id Id do elemento na DOM.
     * @return Elemento na DOM.
     */
    public List<WebElement> findElementsById(String id) {
        return driver.findElements(By.id(id));
    }

    /**
     * Busca os elementos na DOM por seu name.
     * @param name Name do elemento na DOM.
     * @return Elemento na DOM.
     */
    public List<WebElement> findElementsByName(String name) {
        return driver.findElements(By.name(name));
    }

    /**
     * Busca os elementos na DOM por seu seletor CSS.
     * OBS.: Se houver mais de um elemento com o mesmo seletor, retorna o primeiro.
     * @param cssSelector Seletor css do elemento na DOM.
     * @return Elemento na DOM.
     */
    public List<WebElement> findElementsByCssSelector(String cssSelector) {
        return driver.findElements(By.cssSelector(cssSelector));
    }

    /**
     * Busca os elementos na DOM por sua tag.
     * OBS.: Se houver mais de um elemento com a mesma tag, retorna o primeiro.
     * @param tag Nome da tag do elemento.
     * @return Elemento na DOM.
     */
    public List<WebElement> findElementsByTag(String tag) {
        return driver.findElements(By.tagName(tag));
    }

    /**
     * Busca os elementos na DOM por sua tag.
     * OBS.: Se houver mais de um elemento com a mesma classe, retorna o primeiro.
     * @param className Classe do elemento.
     * @return Elemento na DOM.
     */
    public List<WebElement> findElementsByClassName(String className) {
        return driver.findElements(By.className(className));
    }

    /**
     * Busca um elemento na DOM por seu XPath.
     * @param xpath Texto do elemento que se deseja encontrar.
     * @return Elemento na DOM.
     */
    public List<WebElement> findElementsByXPath(String xpath) {
        return driver.findElements(By.xpath(xpath));
    }

    /**
     * Aguarda até um tempo limite pela presença de um elemento na DOM especificado por seu texto.
     * @param timeLimit Tempo limite de espera.
     * @param text Texto do elemento.
     * @return Elemento da DOM.
     */
    public WebElement waitUntilPresenceOfElementByText(int timeLimit, String text) {
        WebDriverWait wait = new WebDriverWait(driver, timeLimit);
        return wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(text)));
    }

    /**
     * Aguarda até um tempo limite pela presença de um elemento na DOM especificado por seu seletor CSS.
     * @param timeLimit Tempo limite de espera.
     * @param cssSelector Seletor CSS do elemento.
     * @return Elemento da DOM.
     */
    public WebElement waitUntilPresenceOfElementByCssSelector(int timeLimit, String cssSelector) {
        WebDriverWait wait = new WebDriverWait(driver, timeLimit);
        return wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(cssSelector)));
    }

    /**
     * Aguarda até um tempo limite pela presença de um elemento na DOM especificado por seu id.
     * @param timeLimit Tempo limite de espera.
     * @param id Id do elemento.
     * @return Elemento da DOM.
     */
    public WebElement waitUntilPresenceOfElementById(int timeLimit, String id) {
        WebDriverWait wait = new WebDriverWait(driver, timeLimit);
        return wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
    }

    /**
     * Aguarda até um tempo limite pela possibilidade do elemento se tornar clicável, buscando o elemento através de
     * seu id
     * @param timeLimit Tempo limite de espera.
     * @param id Id do elemento.
     * @return Elemento a ser clicado.
     */
    public WebElement waitUntilClickableById(int timeLimit, String id) {
        WebDriverWait wait = new WebDriverWait(driver, timeLimit);
        return wait.until(ExpectedConditions.elementToBeClickable(By.id(id)));
    }

    public void waitUntilElementInvisibleByCssSelector(int timeLimit, String cssSelector) {
        WebDriverWait wait = new WebDriverWait(driver, timeLimit);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(cssSelector)));
    }

    /**
     * Cria um intervalo de espera com um tempo e unidade.
     * @param timeLimit Tempo do intervalo.
     * @param unit Unidade de tempo do intervalo.
     */
    public void wait(int timeLimit, TimeUnit unit) {
        driver.manage().timeouts().implicitlyWait(timeLimit, unit);
    }
}
